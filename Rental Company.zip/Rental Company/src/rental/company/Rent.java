package rental.company;
import java.util.Scanner;

// Class 1
//Superclass to get the information of Renter  
class RenterInformation { 

    private int customerID;
    private String firstName;
    private String lastName;
    private String birthdate;
    private String nationality;
    private int mobile;
    private String email;

    //Constructor method
    public RenterInformation () { 
        setCustomerID();
        setFirstName();
        setLastName();
        setBirthdate();
        setNationality();
        setMobile();
        setEmail();
    }
     //methods to (ask the user some information) and (returns the values)
    public void setCustomerID() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter your ID: ");
        this.customerID = input.nextInt();
    }
    
    public int getCustomerID() {
        return customerID;
    }
   
    public void setFirstName() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter your First Name: ");
        this.firstName = input.next();
    }
 
    public String getFirstName() {
        return firstName;
    }
    public void setLastName() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter your Last Name: ");
        this.lastName = input.next();
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setBirthdate() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter your Birthdate: ");
        this.birthdate = input.next();
    }

    public String getBirthdate() {
        return birthdate;
    }
    
    public void setNationality() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter your Nationality: ");
        this.nationality = input.next();
    }

    public String getNationality() {
        return nationality;
    }
    
    public void setMobile() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter your Mobile phone number: ");
        this.mobile = input.nextInt();
    }

    public int getMobile() {
        return mobile;
    }

    public void setEmail() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter your E-mail Address: ");
        this.email = input.next();
    }

    public String getEmail() {
        return email;
    }
    
    /* method to print the information that has been entered by the user. 
       Also, it's overridden with  "ApartmentRent" & "carRent" */
    public void printSummary(){ 
        System.out.println();
        System.out.println("********************************************************************************************************************");
        System.out.println("Summary Report");
        System.out.println("Customer ID : " +getCustomerID());
        System.out.println("First Name : " +getFirstName());
        System.out.println("Last Name : " +getLastName());
        System.out.println("Birthdate : " +getBirthdate());
        System.out.println("Nationality : " +getNationality());
        System.out.println("Mobile Number : " +getMobile());
        System.out.println("E-mail Address : " +getEmail());
    }   
}// End of Class 3 

//******************************************************************************************************************************************
// Class 2

//SubClass inherited from RenterInformation class
class ApartmentRent extends RenterInformation  { 
    private String apartmentType;
    private String address;
    private int period;    
    private double rentCharge;
    
    //Constructor method 
    public ApartmentRent() {
        super(); //  Calling the constructor method from  RenterInformation class
        setApartmentRent();
        setAddress();
        setPeriod();
        setRentCharge();
    }
    
    //methods to (ask the user some information) and (returns the values)
    public void setApartmentRent(){
        boolean flag = false;  
        Scanner input = new Scanner(System.in);
        System.out.print("Please enter how many room would you like to rent ");
        do {
        System.out.print("(A=1,B=2,C=3): ");
        this.apartmentType = input.next();
        
        //A switch statement with the options that the user can enter
        switch (apartmentType) {
                case "A":
                    flag = true;
                    break;
                case "B":
                    flag = true;
                    break;
                case "C":
                    flag = true;
                    break;
            }    
        } while(flag == false);
    }
    
    public String getApartmentType() {
    return apartmentType;
    }
     
    public void setAddress() {
        boolean flag= false;
        Scanner input = new Scanner(System.in);
        System.out.print("Please enter the apartment type you would like to rent ");
		while(flag == false) {		
                        System.out.print("(C1:Luxury-class Area,C2:Good Area,C3:Acceptable Area): ");
                        this.address = input.next();	
			if (address .equals("C1")) {
                            flag = true;
			}
			else if(address .equals("C2"))
			{
                            flag = true;
			}
			else if(address .equals("C3"))
			{
                            flag = true;
			}
		}
    }

    public String getAddress(){
        return address;
 
    }
    
    public void setPeriod() {
	boolean flag= false;
        Scanner input = new Scanner(System.in);
        System.out.print("How many days would you like to stay : ");
        while(flag == false)
        {       // user should enter an integer number 
            if (!input.hasNextInt()) {
                System.out.print("Input is not a number. Enter an integer number : ");
                input.nextLine();
            }else{
                this.period = input.nextInt();
                flag=true;
            }
        }
    }

    public int getPeriod() {
        return period;
    }
    
    public void setRentCharge() {
    int apartmentTypeCost=0;
    double extraAddress=0, periodDiscount = 0, Subtotal_1 , Subtotal_2;
        // apartmentType Calculation    
    if (apartmentType .equals("A")){ 
        apartmentTypeCost = 20;}
    else if (apartmentType .equals("B")){ 
        apartmentTypeCost = 35;}
    else if (apartmentType .equals("C")){ 
        apartmentTypeCost = 45;}
    
        // Address Calculation 
    if (address .equals("C1")){ 
        extraAddress = 0.5;}
    else if (address .equals("C2")){ 
        extraAddress = 0.3;}
    else if (address .equals("C3")){ 
        extraAddress = 0.1;}
  
        // Period Calculation 
    if (period>=1 && period<=3){ 
        periodDiscount = 0;}
    else if (period>=4 && period<=10){ 
        periodDiscount = 0.15;}
    else if (period>=11 && period<=30){ 
        periodDiscount = 0.2;}
    else if (period>=31){ 
        periodDiscount = 0.3;}
    
        // to calculate the total 
    Subtotal_1 = apartmentTypeCost * period ;
    Subtotal_2 = Subtotal_1 - (Subtotal_1 * periodDiscount);
    this.rentCharge = Subtotal_2 + (Subtotal_2 * extraAddress);
    }
    
    public double getRentCharge() {
        return rentCharge;
    }
    
    @Override
    // to override with superclass "RenterInformation" 
    public void printSummary(){
    super.printSummary();
    System.out.println("Apartment Type : " +getApartmentType());
    System.out.println("Address : " +getAddress());
    System.out.println("Period : " +getPeriod() +" days");
    System.out.println("Rent Charge : " +getRentCharge()+ " OMR"); 
    }    
  }// End of Class 2

//******************************************************************************************************************************************
// Class 3 

//This is a subclass (carRent) inherted from superclass "RenterInformation"
class CarRent extends RenterInformation {
    private final int carCostPerDay=10; //constant value
    private String carName;
    private int year;    
    private int period;
    private int distance;
    private double rentCharge; 
    
    //Constructor method
    public CarRent(){
        super(); //  Calling the constructor method from  RenterInformation class
        setCarName();
        setYear();
        setPeriod();
        setDistance();
        setRentCharge();
    }
    //methods to (ask the user some information) and (returns the values)
    public void setCarName() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Car name: ");
        this.carName = input.next();
    }
        
    public String getCarName() {
        return carName;
    }
   
    public void setYear() {
	boolean flag = false;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Car model, ");
        while(flag == false)
        {
             //to make sure that the year is between 2000-2020
            System.out.print("Available models from 2000 to 2020: ");
            this.year = input.nextInt();
            if (year>=2000 && year<=2020) {
                flag=true;
        }
    }
}

    public int getYear() {
        return year;
    }
    
        public void setPeriod() {
	boolean flag = false;
        Scanner input = new Scanner(System.in);
        System.out.print("How many days you want to rent the car : ");
        while(flag == false)
        {
            this.period = input.nextInt();
            if (period>=1) { 
                //to make sure it's 1 or more days
                flag=true;
        }
    }
}

    public int getPeriod() {
        return period;
    }
      
    
    public void setDistance() {
	boolean flag = false;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter km distance of the car: ");
        while(flag == false)
        {
            this.distance = input.nextInt();
            if (distance>1) {
                flag=true;
        }
    }
}

    public int getDistance() {
        return distance;
    }
    
    public void setRentCharge() {
        //varubules
    double carNameExtra=0 , yearExtra = 0 , periodDiscount=0 , distanceCharge ,  Subtotal_1 , Subtotal_2, Subtotal_3; 
        // A switch statement to calculate the extra money according to car type   
    switch (carName) {
        
                case "Mercedes":
                    carNameExtra=0.3;
                    break;
                case "BMW":
                    carNameExtra=0.2;
                    break;
                case "Lexus":
                    carNameExtra=0.15;
                    break;
                default:
                    carNameExtra=1;
                    break;
            }    
        
        // Year Calculation 
    if (year>=2018 && year<=2020){ 
        yearExtra = 0.4;}
    else if (year>=2015 && year<=2017){ 
        yearExtra = 0.2;}
    else{ 
        yearExtra =1;}
  
        // Period Calculation for discount 
    if (period>=1 && period<=3){ 
        periodDiscount = 0;}
    else if (period>=4 && period<=10){ 
        periodDiscount = 0.15;}
    else if (period>=11 && period<=30){ 
        periodDiscount = 0.2;}
    else if (period>=31){ 
        periodDiscount = 0.3;}
    
        // Distance Calculation 
    if (distance <= 200){ 
        distanceCharge = distance * 0.1;}
    else {
    double a = distance - 200;
    double b = 200; 
    distanceCharge = (b * 0.1) + (a * 0.05);
    }
    
        // To get the total of the rent 
    Subtotal_1 = carCostPerDay * period ;
    Subtotal_2 = Subtotal_1 - (Subtotal_1 * periodDiscount);
    Subtotal_3 = Subtotal_2 + (Subtotal_2*yearExtra)+ distanceCharge; 
    this.rentCharge = Subtotal_3 + (Subtotal_3 * carNameExtra);
    
    }
    
    public double getRentCharge() {
        return rentCharge;
    }
        
    @Override
    // to override with superclass "RenterInformation" 
    public void printSummary(){
    super.printSummary();
    System.out.println("Car Name : "+getCarName());
    System.out.println("Model Number : "+getYear());
    System.out.println("Period : " +getPeriod()+" days");
    System.out.println("Distane : " +getDistance()+" KM");
    System.out.println("Rent Charge : " +getRentCharge()+ " OMR"); 
}    
}// End of Class 3 

//******************************************************************************************************************************************
// Class 4 

//This is a class that has the main method 
public class Rent {    
    public static void main(String[] args) {
    int a;
    boolean flag = false;
    Scanner input = new Scanner(System.in);
    //The user will chose what option he would like to proceed
    System.out.print("\t\tWelcome to Rental Company");
    System.out.println("\nFor ApartmentRent press 1\tFor CarRent press 2");
    System.out.print("Your Choice: ");
    
    while (flag == false){
        /*
       When user enter 1 or 2 .. Flag will turn to True
        case 1 to call Apartment Rent
        case 2  call carRent 
        default to make sure that the entered value is (1 or 2)
        */
    a = input.nextInt();
    System.out.println("");
        switch (a) {
            case 1:
                ApartmentRent obj1 = new ApartmentRent();
                obj1.printSummary();
                flag = true;
                break;
            case 2:
                CarRent obj2 = new CarRent();
                obj2.printSummary();
                flag = true;
                break;
            default:
                System.out.print("you Should Enter 1 or 2: ");
                break;
        }
    }
}
}// End of Class 4 
